<li class="menu-has-children"><a href="#">Services</a>
    <ul>
        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><a wire:navigate href="<?php echo e(route('services', ['service_id' => $service->id])); ?>"><?php echo e($service->name); ?></a></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
    </ul>
</li><?php /**PATH G:\craft-copier-colution-2025\craftwebsite\resources\views/livewire/service-dropdown.blade.php ENDPATH**/ ?>