<div>
    <!--[if BLOCK]><![endif]--><?php if(session()->has('repair')): ?>
        <div class="alert alert-success">
            <?php echo e(session('repair')); ?>

        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    <form action="<?php echo e(route('client-repairs.store')); ?>" method="POST" class="form-wrap">
        <?php echo csrf_field(); ?>
        <!-- Client Name -->
        <input type="text" class="form-control" name="client_name" placeholder="Your Full Name" value="<?php echo e(old('client_name')); ?>">
        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['client_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->

        <!-- Contact Number -->
        <input type="text" class="form-control" name="contact_number" placeholder="Your Contact Number" value="<?php echo e(old('contact_number')); ?>">
        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['contact_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->

        <!-- Company Name -->
        <input type="text" class="form-control" name="company_name" placeholder="Printer Company Name" value="<?php echo e(old('company_name')); ?>">
        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['company_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->

        <!-- Model Name -->
        <input type="text" class="form-control" name="model_name" placeholder="Printer Model Name" value="<?php echo e(old('model_name')); ?>">
        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['model_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->

        <!-- Problem Description -->
        <textarea class="form-control" name="problem_description" placeholder="Tell me your printer problem" cols="30" rows="5"><?php echo e(old('problem_description')); ?></textarea>
        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['problem_description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->

        <!-- Submit Button -->
        <button type="submit" class="primary-btn bg-dark text-uppercase">Submit Request</button>
    </form>
</div><?php /**PATH G:\craft-copier-colution-2025\craftwebsite\resources\views/livewire/client-repair.blade.php ENDPATH**/ ?>