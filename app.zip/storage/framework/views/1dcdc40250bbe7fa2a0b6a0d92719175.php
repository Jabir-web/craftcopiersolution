<div>
    

    <div class="row mt-4">
        <!--[if BLOCK]><![endif]--><?php if($machines): ?>
            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $machines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $machine): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-4 col-md-6 mb-4">
                    <div class="card">
                        <img class="card-img-top" src="<?php echo e(asset('storage/' . $machine->image)); ?>" alt="<?php echo e($machine->name); ?>">
                        <div class="card-body">
                            <h5 class="card-title"><?php echo e($machine->name); ?></h5>
                            <p class="card-text"><?php echo e($machine->short_description); ?></p>
                            <a href="<?php echo e($machine->brochure_link); ?>" class="btn btn-primary">Brochure</a>
                            <a href="<?php echo e($machine->driver_link); ?>" class="btn btn-secondary">Driver</a>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
        <?php else: ?>
            <p>No machines found.</p>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
    </div>
</div><?php /**PATH G:\craft-copier-colution-2025\craftwebsite\resources\views/livewire/machine-list.blade.php ENDPATH**/ ?>