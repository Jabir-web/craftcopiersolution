<div>
    <!--[if BLOCK]><![endif]--><?php if(session()->has('accessory')): ?>
        <div class="alert alert-success">
            <?php echo e(session('accessory')); ?>

        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    <form action="<?php echo e(route('accessory-requests.store')); ?>" method="POST" class="form-wrap">
        <?php echo csrf_field(); ?>
        <!-- Company Name -->
        <input type="text" class="form-control" name="company_name" placeholder="Printer Company Name" value="<?php echo e(old('company_name')); ?>">
        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['company_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->

        <!-- Model Name -->
        <input type="text" class="form-control" name="model_name" placeholder="Printer Model Name" value="<?php echo e(old('model_name')); ?>">
        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['model_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->

        <!-- Accessory Dropdown -->
        <select class="form-control py-2" name="accessory">
            <option selected disabled>Select Accessories</option>
            <option value="Drum" <?php echo e(old('accessory') == 'Drum' ? 'selected' : ''); ?>>Drum</option>
            <option value="Cleaning Blade" <?php echo e(old('accessory') == 'Cleaning Blade' ? 'selected' : ''); ?>>Cleaning Blade</option>
            <option value="Toner Cartridge" <?php echo e(old('accessory') == 'Toner Cartridge' ? 'selected' : ''); ?>>Toner Cartridge</option>
            <option value="Developer" <?php echo e(old('accessory') == 'Developer' ? 'selected' : ''); ?>>Developer</option>
            <option value="Charge Roller" <?php echo e(old('accessory') == 'Charge Roller' ? 'selected' : ''); ?>>Charge Roller</option>
            <option value="Feed Roller" <?php echo e(old('accessory') == 'Feed Roller' ? 'selected' : ''); ?>>Feed Roller</option>
            <option value="Heat Roller" <?php echo e(old('accessory') == 'Heat Roller' ? 'selected' : ''); ?>>Heat Roller</option>
            <option value="Pick Up Roller" <?php echo e(old('accessory') == 'Pick Up Roller' ? 'selected' : ''); ?>>Pick Up Roller</option>
            <option value="Pressure Roller" <?php echo e(old('accessory') == 'Pressure Roller' ? 'selected' : ''); ?>>Pressure Roller</option>
        </select>
        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['accessory'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->

        <!-- Full Name -->
        <input type="text" class="form-control" name="fullname" placeholder="Fullname" value="<?php echo e(old('fullname')); ?>">
        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['fullname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->

        <!-- Contact Number -->
        <input type="text" class="form-control" name="contact_number" placeholder="Contact Number" value="<?php echo e(old('contact_number')); ?>">
        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['contact_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->

        <!-- Submit Button -->
        <button type="submit" class="primary-btn bg-dark text-uppercase">Submit Request</button>
    </form>
</div><?php /**PATH G:\craft-copier-colution-2025\craftwebsite\resources\views/livewire/accessories-form.blade.php ENDPATH**/ ?>