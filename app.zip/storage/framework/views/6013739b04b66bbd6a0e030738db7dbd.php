<div>
    <!--[if BLOCK]><![endif]--><?php if(session()->has('rent')): ?>
        <div class="alert alert-success">
            <?php echo e(session('rent')); ?>

        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    <form action="<?php echo e(route('client-rentals.store')); ?>" method="POST" class="form-wrap">
        <?php echo csrf_field(); ?>
        <!-- Client Name -->
        <input type="text" class="form-control" name="client_name" placeholder="Client Name" value="<?php echo e(old('client_name')); ?>">
        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['client_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->

        <!-- Client Company Name -->
        <input type="text" class="form-control" name="client_company_name" placeholder="Client Company Name" value="<?php echo e(old('client_company_name')); ?>">
        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['client_company_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->

        <!-- City Name -->
        <input type="text" class="form-control" name="city_name" placeholder="Your City Name" value="<?php echo e(old('city_name')); ?>">
        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['city_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->

        <!-- Contact Number -->
        <input type="text" class="form-control" name="contact_number" placeholder="Contact Number" value="<?php echo e(old('contact_number')); ?>">
        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['contact_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->

        <!-- Requirements -->
        <textarea class="form-control" name="requirements" placeholder="Your Requirements .." cols="30" rows="5"><?php echo e(old('requirements')); ?></textarea>
        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['requirements'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->

        <!-- Submit Button -->
        <button type="submit" class="primary-btn bg-dark text-uppercase">Submit Request</button>
    </form>
</div><?php /**PATH G:\craft-copier-colution-2025\craftwebsite\resources\views/livewire/client-rental.blade.php ENDPATH**/ ?>