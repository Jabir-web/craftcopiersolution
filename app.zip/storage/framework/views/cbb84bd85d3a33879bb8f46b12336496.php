<div>
    <section class="recent-blog-area section-gap">
        <div class="container">
            <div class="row d-flex justify-content-center">
                <div class="menu-content pb-60 col-lg-9">
                    <div class="title text-center">
                        <h1 class="mb-10">Latest from Our Blog</h1>
                        <p>With the exception of Nietzsche, no other madman has contributed so much to human sanity as has.</p>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="active-recent-blog-carusel">
                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="single-recent-blog-post item">
                            <div class="thumb">
                                <img class="img-fluid" src="<?php echo e(Storage::url($blog->img)); ?>" alt="<?php echo e($blog->title); ?>">
                            </div>
                            <div class="details">
                                <div class="tags">
                                    <ul>
                                        <li>
                                            <a href="#"><?php echo e($blog->category); ?></a>
                                        </li>
                                    </ul>
                                </div>
                                <a href="#">
                                    <h4 class="title"><?php echo e($blog->title); ?></h4>
                                </a>
                                <p><?php echo $blog->description; ?></p>
                                <h6 class="date"><?php echo e($blog->created_at->format('F j, Y')); ?></h6>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                </div>
            </div>
        </div>
    </section>
</div>
<?php /**PATH G:\craft-copier-colution-2025\craftwebsite\resources\views/livewire/blog-list.blade.php ENDPATH**/ ?>