<li class="menu-has-children"><a href="#">Products</a>
    <ul>
        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><a wire:navigate href="<?php echo e(route('machines', ['product_id' => $product->id])); ?>"><?php echo e($product->name); ?></a></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
    </ul>
</li><?php /**PATH G:\craft-copier-colution-2025\craftwebsite\resources\views/livewire/product-dropdown.blade.php ENDPATH**/ ?>