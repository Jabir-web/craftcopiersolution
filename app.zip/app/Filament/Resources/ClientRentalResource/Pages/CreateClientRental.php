<?php

namespace App\Filament\Resources\ClientRentalResource\Pages;

use App\Filament\Resources\ClientRentalResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateClientRental extends CreateRecord
{
    protected static string $resource = ClientRentalResource::class;
}
