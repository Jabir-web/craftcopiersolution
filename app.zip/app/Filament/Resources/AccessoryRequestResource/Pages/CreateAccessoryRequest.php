<?php

namespace App\Filament\Resources\AccessoryRequestResource\Pages;

use App\Filament\Resources\AccessoryRequestResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateAccessoryRequest extends CreateRecord
{
    protected static string $resource = AccessoryRequestResource::class;
}
